package com.ccet.student;

import android.os.Bundle;
import android.app.Activity;

public class commonWebFile extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.web);
    }
}
