package com.ccet.student;

import android.app.Activity;
import android.content.SharedPreferences;

public class oneTimeInitialization extends Activity {
	
	SharedPreferences sharedPreferences ;
	public void insertData()
	{
		
	}
}
