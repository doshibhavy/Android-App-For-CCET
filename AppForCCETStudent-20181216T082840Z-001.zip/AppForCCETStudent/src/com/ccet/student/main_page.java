package com.ccet.student;

import android.os.Bundle;
import android.app.Activity;

public class main_page extends Activity {
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_page);
        
        
        
	}
}
